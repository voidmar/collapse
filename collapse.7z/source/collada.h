#pragma once

#include "collada_common.h"
#include "collada_dataflow.h"
#include "collada_animation.h"
#include "collada_image.h"
#include "collada_material.h"
#include "collada_effect.h"
#include "collada_geometry.h"
#include "collada_scene.h"

struct Collada
{
	LibraryAnimations library_animations;
	LibraryImages library_images;
	LibraryMaterials library_materials;
	effect::LibraryEffects library_effects;
	LibraryGeometries library_geometries;
	LibraryVisualScenes library_visual_scenes;

	void read(xml::XMLElement* element)
	{
		xml::XMLElement* library_animations_element = element->FirstChildElement("library_animations");
		if (library_animations_element)
		{
			library_animations.read(library_animations_element);
		}

		xml::XMLElement* library_images_element = element->FirstChildElement("library_images");
		if (library_images_element)
		{
			library_images.read(library_images_element);
		}

		xml::XMLElement* library_materials_element = element->FirstChildElement("library_materials");
		assert(library_materials_element);
		library_materials.read(library_materials_element);

		xml::XMLElement* library_effects_element = element->FirstChildElement("library_effects");
		assert(library_effects_element);
		library_effects.read(library_effects_element);

		xml::XMLElement* library_geometries_element = element->FirstChildElement("library_geometries");
		assert(library_geometries_element);
		library_geometries.read(library_geometries_element);

		xml::XMLElement* library_visual_scenes_element = element->FirstChildElement("library_visual_scenes");
		assert(library_visual_scenes_element);
		library_visual_scenes.read(library_visual_scenes_element);
	}

	void write(xml::XMLPrinter& printer)
	{
		if (library_animations.animations.size() > 0)
		{
			printer.OpenElement("library_animations");
			library_animations.write(printer);
			printer.CloseElement();
		}

		if (library_images.images.size() > 0)
		{
			printer.OpenElement("library_images");
			library_images.write(printer);
			printer.CloseElement();
		}

		printer.OpenElement("library_materials");
		library_materials.write(printer);
		printer.CloseElement();

		printer.OpenElement("library_effects");
		library_effects.write(printer);
		printer.CloseElement();

		printer.OpenElement("library_geometries");
		library_geometries.write(printer);
		printer.CloseElement();

		printer.OpenElement("library_visual_scenes");
		library_visual_scenes.write(printer);
		printer.CloseElement();
	}
};