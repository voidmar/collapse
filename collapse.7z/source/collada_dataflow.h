#pragma once
#include "collada_common.h"

struct FloatArray
{
	//	std::string			id;
	uint32_t			count;
	std::vector<float>	data;

	void read(xml::XMLElement* element)
	{
		count = element->UnsignedAttribute("count");
		assert(count > 0);

		const char* data_text = element->GetText();
		assert(data_text);

		data.resize(count);
		ReadFloatArray(data.data(), count, data_text);
	}

	void write(xml::XMLPrinter& printer)
	{
		printer.PushAttribute("count", count);

		std::string value = WriteFloatArray(data.data(), data.size());
		printer.PushText(value.c_str());
	}
};

struct Param
{
	std::string type;
	std::string name;

	void read(xml::XMLElement* element)
	{
		type = element->Attribute("type");
		name = element->Attribute("name");
	}

	void write(xml::XMLPrinter& printer)
	{
		if (type != "") printer.PushAttribute("type", type.c_str());
		if (name != "") printer.PushAttribute("name", name.c_str());
	}
};

struct Accessor
{
	int stride;
	std::vector<Param> params;

	void read(xml::XMLElement* element)
	{
		stride = element->IntAttribute("stride");

		ReadMultipleElements(element, "param", params);
	}

	void write(xml::XMLPrinter& printer)
	{
		printer.PushAttribute("stride", stride);

		WriteMultipleElements(printer, "param", params);
	}
};

struct BlobReference
{
	uint32_t offset;
	uint32_t size;

	void write(xml::XMLPrinter& printer)
	{
		printer.PushAttribute("offset", offset);
		printer.PushAttribute("size", size);
	}
};

struct Source
{
	std::string id;
	std::shared_ptr<FloatArray> float_array;
	Accessor accessor;
	std::shared_ptr<BlobReference> blob_reference;

	void read(xml::XMLElement* element)
	{
		id = element->Attribute("id");

		xml::XMLElement* float_array_element = element->FirstChildElement("float_array");
		if (float_array_element)
		{
			float_array.reset(new FloatArray());
			float_array->read(float_array_element);
		}

		xml::XMLElement* technique_common_element = element->FirstChildElement("technique_common");
		assert(technique_common_element);

		xml::XMLElement* accessor_element = technique_common_element->FirstChildElement("accessor");
		assert(accessor_element);
		accessor.read(accessor_element);
	}

	void write(xml::XMLPrinter& printer)
	{
		printer.PushAttribute("id", id.c_str());

		if (blob_reference)
		{
			printer.OpenElement("blob_reference");
			blob_reference->write(printer);
			printer.CloseElement();
		}

		if (float_array)
		{
			printer.OpenElement("float_array");
			float_array->write(printer);
			printer.CloseElement();
		}

		printer.OpenElement("technique_common");

		printer.OpenElement("accessor");
		accessor.write(printer);
		printer.CloseElement();

		printer.CloseElement();
	}
};

struct Input
{
	std::string semantic;
	std::string source;
	uint32_t offset;
	uint32_t set;

	Input() :
	offset(~0u),
		set(~0u)
	{
	}

	void read(xml::XMLElement* element)
	{
		semantic = element->Attribute("semantic");
		source = element->Attribute("source");

		offset = ~0u;
		element->QueryUnsignedAttribute("offset", &offset);

		set = ~0u;
		element->QueryUnsignedAttribute("set", &set);
	}

	void write(xml::XMLPrinter& printer)
	{
		printer.PushAttribute("semantic", semantic.c_str());
		printer.PushAttribute("source", source.c_str());

		if (offset != ~0u)
		{
			printer.PushAttribute("offset", offset);
		}

		if (set != ~0u)
		{
			printer.PushAttribute("set", set);
		}
	}
};