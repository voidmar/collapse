#pragma once
#include "collada_common.h"

struct Image
{
	std::string id;
	std::string name;
	std::string init_from;

	void read(xml::XMLElement* element)
	{
		id = element->Attribute("id");
		name = element->Attribute("name");

		init_from = GetText(element->FirstChildElement("init_from"));
	}

	void write(xml::XMLPrinter& writer)
	{
		writer.PushAttribute("id", id.c_str());
		writer.PushAttribute("name", name.c_str());

		writer.OpenElement("init_from");
		writer.PushText(init_from.c_str());
		writer.CloseElement();
	}
};

struct LibraryImages
{
	std::vector<Image> images;

	void read(xml::XMLElement* element)
	{
		ReadMultipleElements(element, "image", images);
	}

	void write(xml::XMLPrinter& writer)
	{
		WriteMultipleElements(writer, "image", images);
	}
};