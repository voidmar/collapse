#include <string>
#include <unordered_set>
#include <unordered_map>
#include <assert.h>

#include <shlwapi.h>
#pragma comment(lib, "shlwapi.lib")

#include "tinyxml2.h"
namespace xml = tinyxml2;

#include "collada.h"

#include <d3dx9shader.h>
#pragma comment(lib, "d3dx9.lib")

struct BlobFile
{
	typedef std::pair<uint32_t, std::vector<uint8_t>> Blob;

	uint32_t			offset;
	std::vector<Blob>	blobs;

	BlobFile(): offset(0)
	{

	}

	template <typename T>
	std::shared_ptr<BlobReference> add_blob(T* data, uint32_t size)
	{
		std::pair<uint32_t, std::vector<uint8_t>> blob;
		blob.first = offset;
		blob.second.assign((uint8_t*)(data), (uint8_t*)(data + size));
		blobs.emplace_back(std::move(blob));

		offset += size * sizeof(T);
		int pad = offset % 4;
		if (pad) offset += 4 - pad;

		std::shared_ptr<BlobReference> blob_ref(new BlobReference());
		blob_ref->offset = blob.first;
		blob_ref->size = size * sizeof(T);
		return blob_ref;
	}

	void write(FILE* file)
	{
		for (auto it = blobs.begin(); it != blobs.end(); ++it)
		{
			fseek(file, it->first, SEEK_SET);
			fwrite(it->second.data(), it->second.size(), 1, file);
		}
	}
};

void convert_sources_into_blobs(std::vector<Source>& sources, BlobFile& blob_file)
{
	for (auto source_it = sources.begin(); source_it != sources.end(); ++source_it)
	{
		std::shared_ptr<FloatArray> float_array = source_it->float_array;

		source_it->blob_reference = blob_file.add_blob(float_array->data.data(), float_array->data.size());
		source_it->float_array = nullptr;
	}
}

struct InstanceSet
{
	std::unordered_set<std::string> instances;

	void insert(const std::string& instance)
	{
		instances.insert(instance);
	}

	bool contains(const std::string& instance)
	{
		return instances.find(instance) != instances.end();
	}
};

struct InstanceToInstanceSetMap
{
	std::unordered_map<std::string, InstanceSet> instances;

	void insert(const std::string& instance, const std::string& used_by)
	{
		auto instance_it = instances.find(instance);
		if (instance_it == instances.end())
		{
			instance_it = instances.emplace(std::make_pair(instance, InstanceSet())).first;
		}

		instance_it->second.insert(used_by);
	}

	bool contains(const std::string& instance)
	{
		return instances.find(instance) != instances.end();
	}

	InstanceSet& get_used_by(const std::string& instance)
	{
		auto instance_it = instances.find(instance);
		if (instance_it == instances.end())
		{
			static InstanceSet empty_instance_set;
			return empty_instance_set;
		}

		return instance_it->second;
	}
};

//typedef  InstanceToInstanceSetMap;

InstanceSet dynamic_shader_variables;

void collect_materials(Node& node, InstanceToInstanceSetMap& materials)
{
	for (auto geometry_it = node.instance_geometries.begin(); geometry_it != node.instance_geometries.end(); ++geometry_it)
	{
		std::string geometry_id= geometry_it->url.substr(1);
		for (auto material_it = geometry_it->instance_materials.begin(); material_it != geometry_it->instance_materials.end(); ++material_it)
		{
			std::string material_name = material_it->target.substr(1);
			materials.insert(material_name, geometry_id);
		}
	}
	
	for (auto node_it = node.nodes.begin(); node_it != node.nodes.end(); ++node_it)
	{
		collect_materials(*node_it, materials);
	}
}


std::wstring path_from_collada(const wchar_t* collada_path, const std::string& relative_filename)
{
	wchar_t path[MAX_PATH];
	wchar_t collada_directory[MAX_PATH];
	wcscpy_s(collada_directory, collada_path);
	PathRemoveFileSpec(collada_directory);

	std::wstring filename;
	filename.assign(relative_filename.begin(), relative_filename.end());
	std::for_each(filename.begin(), filename.end(), [](wchar_t& c){ if (c == '/') c = '\\';});
	PathCombine(path, collada_directory, filename.c_str());

	return path;
}

void CollapseFile(const wchar_t* source_filename, const wchar_t* target_filename)
{
	FILE* file;
	_wfopen_s(&file, source_filename, L"r");

	xml::XMLDocument xml_doc;
	xml_doc.LoadFile(file);

	fclose(file);

	Collada collada;
	collada.read(xml_doc.RootElement());

	BlobFile blob_file;
	// remove unused INTERPOLATION input from animation
	LibraryAnimations& library_animations = collada.library_animations;
	for (auto it = library_animations.animations.begin(); it != library_animations.animations.end(); ++it)
	{
		Animation& animation = *it;
		for (auto sampler_it = animation.samplers.begin(); sampler_it != animation.samplers.end(); ++sampler_it)
		{
			Sampler& sampler = *sampler_it;

			auto input_it = sampler.inputs.begin();
			while (input_it != sampler.inputs.end())
			{
				if (input_it->semantic == "INTERPOLATION")
				{
					std::string source_id = input_it->source.substr(1);

					auto source_it = animation.sources.begin();
					while (source_it != animation.sources.end())
					{
						if (source_it->id == source_id)
						{
							source_it = animation.sources.erase(source_it);
							continue;
						}
						else ++source_it;
					}
					input_it = sampler.inputs.erase(input_it);
					continue;
				}
				else ++input_it;
			}
		}
	}

	// turn remaining animation sources into blobs
	for (auto it = library_animations.animations.begin(); it != library_animations.animations.end(); ++it)
	{
		convert_sources_into_blobs(it->sources, blob_file);
	}

	InstanceToInstanceSetMap used_materials; // material id to geometry ids
	InstanceToInstanceSetMap used_effects; // effect id to material ids
	InstanceToInstanceSetMap used_vertex_semantics; // semantic to effect id

	// collect used materials from nodes
	VisualScene& scene = collada.library_visual_scenes.visual_scenes.front();
	for (auto node_it = scene.nodes.begin(); node_it != scene.nodes.end(); ++node_it)
	{
		collect_materials(*node_it, used_materials);
	}

	// remove unused materials and collect used effects from materials
	auto material_it = collada.library_materials.materials.begin();
	while (material_it != collada.library_materials.materials.end())
	{
		if (!used_materials.contains(material_it->id))
		{
			material_it = collada.library_materials.materials.erase(material_it);
			continue;
		}

		used_effects.insert(material_it->instance_effect_url.substr(1), material_it->id);
		++material_it;
	}

	// remove unused effects
	auto effect_it = collada.library_effects.effects.begin();
	while (effect_it != collada.library_effects.effects.end())
	{
		if (!used_effects.contains(effect_it->id))
		{
			effect_it = collada.library_effects.effects.erase(effect_it);
			continue;
		}

		InstanceSet used_params;

		assert(effect_it->profile_cgs.size() == 1);
		effect::ProfileCg& profile_cg = effect_it->profile_cgs.back();

		assert(profile_cg.techniques.size() == 1);
		effect::Technique& technique = profile_cg.techniques.back();

		for (auto pass_it = technique.passes.begin(); pass_it != technique.passes.end(); ++pass_it)
		{
			for (auto shader_it = pass_it->shaders.begin(); shader_it != pass_it->shaders.end(); ++shader_it)
			{
				effect::Include* shader_include = profile_cg.get_include_from_sid(shader_it->source);
				assert(shader_include);

				std::wstring shader_path = path_from_collada(source_filename, shader_include->url);
				assert(shader_path != L"");

				D3DXMACRO shader_macros[] = 
				{
					{ "__psp2__", "1" },
					{ "__msaa", ""},
					{ "__msaa2x", ""},
					{ "__msaa4x", ""},
					{ "__regformat", ""},
					{ "__nativecolor", ""},
					{ "__nostrip", ""},
					{ nullptr, nullptr }
				};

				const char* shader_profile = nullptr;
				if (shader_it->stage == "VERTEX") shader_profile = "vs_3_0";
				else if (shader_it->stage == "FRAGMENT") shader_profile = "ps_3_0";
				else assert(false);

				LPD3DXBUFFER compiled_shader_buffer = nullptr;
				LPD3DXCONSTANTTABLE shader_constants = nullptr;
				HRESULT compile_result = D3DXCompileShaderFromFile(shader_path.c_str(), shader_macros, nullptr, "main", shader_profile, 0, &compiled_shader_buffer, nullptr, &shader_constants);
				assert(SUCCEEDED(compile_result));

				D3DXCONSTANTTABLE_DESC shader_desc;
				shader_constants->GetDesc(&shader_desc);

				InstanceSet used_binds;
				for (UINT constant_index = 0; constant_index < shader_desc.Constants; ++constant_index)
				{
					D3DXHANDLE constant = shader_constants->GetConstant(NULL, constant_index);

					UINT max_desc_count = 1;
					D3DXCONSTANT_DESC constant_desc;
					shader_constants->GetConstantDesc(constant, &constant_desc, &max_desc_count);

					const char* constant_name = constant_desc.Name + 1;
					if (!dynamic_shader_variables.contains(constant_name))
					{
						used_binds.insert(constant_name);
					}
				}

				auto bind_it = shader_it->binds.begin();
				while (bind_it != shader_it->binds.end())
				{
					if (!used_binds.contains(bind_it->symbol))
					{
						bind_it = shader_it->binds.erase(bind_it);
						continue;
					}
					else
					{
						used_params.insert(bind_it->ref);
					}
					++bind_it;
				}

				if (shader_it->stage == "VERTEX")
				{
					DWORD* compiled_shader = (DWORD*)compiled_shader_buffer->GetBufferPointer();
					D3DXSEMANTIC input_semantics[MAXD3DDECLLENGTH];
					UINT input_semantic_count = 0;
					D3DXGetShaderInputSemantics(compiled_shader, input_semantics, &input_semantic_count);

					for (UINT i = 0; i < input_semantic_count; ++i)
					{
						std::string semantic_name;
						switch(input_semantics[i].Usage)
						{
						case D3DDECLUSAGE_POSITION: semantic_name = "POSITION"; break;
						case D3DDECLUSAGE_NORMAL: semantic_name = "NORMAL"; break;
						case D3DDECLUSAGE_TEXCOORD: semantic_name = "TEXCOORD"; break;
						case D3DDECLUSAGE_TANGENT: semantic_name = "TEXTANGENT"; break;
						case D3DDECLUSAGE_BINORMAL: semantic_name = "TEXBINORMAL"; break;
						case D3DDECLUSAGE_COLOR: semantic_name = "COLOR"; break;
						}
						semantic_name.push_back('0' + input_semantics[i].UsageIndex);

						used_vertex_semantics.insert(semantic_name, effect_it->id);
					}
				}
			}
		}

		for (auto param_it = profile_cg.new_params.begin(); param_it != profile_cg.new_params.end(); ++param_it)
		{
			if (param_it->value_type == effect::Value::Sampler2D)
			{
				if (used_params.contains(param_it->sid))
				{
					used_params.insert(param_it->sampler_value->source);
				}
			}
		}

		auto param_it = profile_cg.new_params.begin();
		while(param_it != profile_cg.new_params.end())
		{
			if (!used_params.contains(param_it->sid))
			{
				param_it = profile_cg.new_params.erase(param_it);
				continue;
			}
			++param_it;
		}

		++effect_it;
	}


	LibraryGeometries& library_geometries = collada.library_geometries;

	InstanceToInstanceSetMap geometry_to_vertex_semantics;
	for(auto vertex_semantic_it = used_vertex_semantics.instances.begin(); vertex_semantic_it != used_vertex_semantics.instances.end(); ++vertex_semantic_it)
	{
		InstanceSet& effect_ids = vertex_semantic_it->second;
		for (auto effect_id_it = effect_ids.instances.begin(); effect_id_it != effect_ids.instances.end(); ++effect_id_it)
		{
			InstanceSet& material_ids = used_effects.get_used_by(*effect_id_it);
			for (auto material_id_it = material_ids.instances.begin(); material_id_it != material_ids.instances.end(); ++material_id_it)
			{
				InstanceSet& geometry_ids = used_materials.get_used_by(*material_id_it);
				for (auto geometry_id_it = geometry_ids.instances.begin(); geometry_id_it != geometry_ids.instances.end(); ++geometry_id_it)
				{
					geometry_to_vertex_semantics.insert(*geometry_id_it, vertex_semantic_it->first);
				}
			}
		}
	}

	// remove unused vertex sources
	for (auto it = library_geometries.geometries.begin(); it != library_geometries.geometries.end(); ++it)
	{
		Mesh& mesh = it->mesh;

		InstanceSet& used_input_semantics = geometry_to_vertex_semantics.get_used_by(it->name);
		InstanceSet used_sources;

		// remove unused inputs from vertices (should be none)
		auto vertex_input_it = mesh.vertices.inputs.begin();
		while (vertex_input_it != mesh.vertices.inputs.end())
		{
			std::string semantic_name = vertex_input_it->semantic + '0';
			if (!used_input_semantics.contains(semantic_name))
			{
				vertex_input_it = mesh.vertices.inputs.erase(vertex_input_it);
				continue;
			}
			else
			{
				used_sources.insert(vertex_input_it->source.substr(1));
			}

			++vertex_input_it;
		}

		// remove unused inputs from triangles
		for (auto triangle_it = mesh.triangles.begin(); triangle_it != mesh.triangles.end(); ++triangle_it)
		{
			std::vector<uint32_t> old_offsets;

			auto input_it = triangle_it->inputs.begin();
			while (input_it != triangle_it->inputs.end())
			{
				if (input_it->semantic != "VERTEX")
				{
					char semantic_index = input_it->set == ~0u ? '0' : '0' + input_it->set;
					std::string semantic_name = input_it->semantic + semantic_index;

					if (!used_input_semantics.contains(semantic_name))
					{
						input_it = triangle_it->inputs.erase(input_it);
						continue;
					}
					else
					{
						used_sources.insert(input_it->source.substr(1));
					}
				}
				else
				{
					used_sources.insert(input_it->source.substr(1));
				}

				auto offset_it = std::find(old_offsets.begin(), old_offsets.end(), input_it->offset);
				if (offset_it == old_offsets.end())
				{
					offset_it = old_offsets.insert(old_offsets.end(),input_it->offset);
				}

				input_it->offset = std::distance(old_offsets.begin(), offset_it);

				++input_it;
			}

			int new_index_stride = old_offsets.size();
			std::vector<long> new_indices;
			new_indices.reserve(new_index_stride * 3 * triangle_it->count);

			int old_index_stride = triangle_it->index_stride;
			std::vector<long>& old_indices = triangle_it->indices;

			for (auto old_index_it = old_indices.begin(); old_index_it != old_indices.end(); old_index_it += old_index_stride)
			{
				for (auto offset_it = old_offsets.begin(); offset_it != old_offsets.end(); ++offset_it)
				{
					new_indices.push_back(*(old_index_it + *offset_it));
				}
			}

			triangle_it->indices = std::move(new_indices);
			triangle_it->index_stride = new_index_stride;
		}

		// remove unused sources
		auto source_it = mesh.sources.begin();
		while (source_it != mesh.sources.end())
		{
			if (!used_sources.contains(source_it->id))
			{
				source_it = mesh.sources.erase(source_it);
				continue;
			}

			++source_it;
		}
	}

	// turn geometry sources into blobs and remove "params"
	for (auto it = library_geometries.geometries.begin(); it != library_geometries.geometries.end(); ++it)
	{
		Mesh& mesh = it->mesh;

		convert_sources_into_blobs(mesh.sources, blob_file);

		for (auto source_it = mesh.sources.begin(); source_it != mesh.sources.end(); ++source_it)
		{
			source_it->accessor.params.clear();
		}

		for (auto triangle_it = mesh.triangles.begin(); triangle_it != mesh.triangles.end(); ++triangle_it)
		{
			std::vector<uint16_t> short_indices;
			short_indices.reserve(triangle_it->indices.size());
			for (auto index_it = triangle_it->indices.begin(); index_it != triangle_it->indices.end(); ++index_it)
			{
				short_indices.push_back((uint16_t)*index_it);
			}
			triangle_it->blob_reference = blob_file.add_blob(short_indices.data(), short_indices.size());
		}
	}

	// write out the blob
	wchar_t blob_filename[MAX_PATH];
	wcscpy_s(blob_filename, target_filename);

	PathRemoveExtension(blob_filename);
	PathAddExtension(blob_filename, L".blob");

	_wfopen_s(&file, blob_filename, L"wb");

	blob_file.write(file);
	fclose(file);


	// write out the collada-ish file
	_wfopen_s(&file, target_filename, L"w");

	xml::XMLPrinter printer(file);
	printer.PushComment(" This file was automatically generated by collapse and isn't at all compatible with real COLLADA implementations ");
	
	printer.OpenElement("COLLADA");
	collada.write(printer);
	printer.CloseElement();

	fclose(file);
}

int wmain(int argc, wchar_t* argv[])
{

	dynamic_shader_variables.insert("World");
	dynamic_shader_variables.insert("WorldInverseTranspose");
	dynamic_shader_variables.insert("WorldViewProjection");
	dynamic_shader_variables.insert("ViewInverse");
	dynamic_shader_variables.insert("Light0Pos");
	dynamic_shader_variables.insert("Light1Pos");
	dynamic_shader_variables.insert("Light2Pos");
	dynamic_shader_variables.insert("Light3Pos");
	dynamic_shader_variables.insert("Light0Color");
	dynamic_shader_variables.insert("Light1Color");
	dynamic_shader_variables.insert("Light2Color");
	dynamic_shader_variables.insert("Light3Color");
	dynamic_shader_variables.insert("Kc");
	dynamic_shader_variables.insert("K1");
	dynamic_shader_variables.insert("K2");
	dynamic_shader_variables.insert("Time");

	assert(argc > 1);

	const wchar_t* source_filename = argv[1];
	const wchar_t* target_filename = nullptr;

	if (argc == 2)
	{
		static wchar_t target_filename_storage[MAX_PATH];
		wcscpy_s(target_filename_storage, source_filename);
		PathRemoveExtension(target_filename_storage);
		PathAddExtension(target_filename_storage, L".xml");

		target_filename = target_filename_storage;
	}
	else
	{
		target_filename = argv[2];
	}

	CollapseFile(source_filename, target_filename);
}