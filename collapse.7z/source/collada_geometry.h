#pragma once
#include <algorithm>
#include "collada_common.h"
#include "collada_dataflow.h"

struct Vertices
{
	std::string id;
	std::vector<Input> inputs;

	void read(xml::XMLElement* element)
	{
		id = element->Attribute("id");

		ReadMultipleElements(element, "input", inputs);
	}

	void write(xml::XMLPrinter& printer)
	{
		printer.PushAttribute("id", id.c_str());

		WriteMultipleElements(printer, "input", inputs);
	}
};

struct Triangles
{
	std::string material;
	uint32_t count;
	std::vector<Input> inputs;

	uint32_t index_stride;
	std::vector<long> indices;

	std::shared_ptr<BlobReference> blob_reference;

	void read(xml::XMLElement* element)
	{
		material = element->Attribute("material");

		count = element->UnsignedAttribute("count");
		assert(count > 0);

		ReadMultipleElements(element, "input", inputs);

		uint32_t max_offset = 0;
		std::for_each(inputs.begin(), inputs.end(), [&max_offset](Input& that) 
		{
			if (that.offset > max_offset) max_offset = that.offset;
		});

		index_stride = max_offset + 1;

		xml::XMLElement* indices_element = element->FirstChildElement("p");
		assert(indices_element);

		const char* indices_text = indices_element->GetText();
		int index_count = index_stride * 3 * count;
		indices.resize(index_count);
		ReadLongArray(indices.data(), index_count, indices_text);
	}

	void write(xml::XMLPrinter& printer)
	{
		printer.PushAttribute("material", material.c_str());

		printer.PushAttribute("count", count);

		WriteMultipleElements(printer, "input", inputs);

		if (blob_reference)
		{
			printer.OpenElement("blob_reference");
			blob_reference->write(printer);
			printer.CloseElement();
		}
		else
		{
			std::string indices_text = WriteLongArray(indices.data(), indices.size());

			printer.OpenElement("p");
			printer.PushText(indices_text.c_str());
			printer.CloseElement();
		}
	}
};

struct Mesh
{
	std::vector<Source> sources;
	Vertices vertices;
	std::vector<Triangles> triangles;

	void read(xml::XMLElement* element)
	{
		ReadMultipleElements(element, "source", sources);

		vertices.read(element->FirstChildElement("vertices"));

		ReadMultipleElements(element, "triangles", triangles);
	}

	void write(xml::XMLPrinter& printer)
	{
		WriteMultipleElements(printer, "source", sources);

		printer.OpenElement("vertices");
		vertices.write(printer);
		printer.CloseElement();

		WriteMultipleElements(printer, "triangles", triangles);
	}
};

struct Geometry
{
	std::string id;
	std::string name;
	Mesh mesh;

	void read(xml::XMLElement* element)
	{
		id = element->Attribute("id");
		name = element->Attribute("name");

		xml::XMLElement* mesh_element = element->FirstChildElement("mesh");
		mesh.read(mesh_element);
	}

	void write(xml::XMLPrinter& printer)
	{
		printer.PushAttribute("id", id.c_str());
		printer.PushAttribute("name", name.c_str());

		printer.OpenElement("mesh");
		mesh.write(printer);
		printer.CloseElement();
	}
};

struct LibraryGeometries
{
	std::vector<Geometry> geometries;

	void read(xml::XMLElement* element)
	{
		assert(strcmp(element->Value(), "library_geometries") == 0);

		ReadMultipleElements(element, "geometry", geometries);
	}

	void write(xml::XMLPrinter& printer)
	{
		WriteMultipleElements(printer, "geometry", geometries);
	}

	Geometry* get_by_id(const std::string& id)
	{
		for (auto it = geometries.begin(); it != geometries.end(); ++it)
		{
			if (it->id == id) return &*it;
		}
		return nullptr;
	}
};