#pragma once
#include "collada_common.h"

namespace effect
{
	namespace Value
	{
		enum Type
		{
			Float,

			Surface,
			Sampler1D,
			Sampler2D,

			Invalid
		};
	}

	struct Surface
	{
		std::string init_from;

		void read(xml::XMLElement* element)
		{
			assert(strcmp(element->Value(), "surface") == 0);

			init_from = GetText(element->FirstChildElement("init_from"));
		}

		void write(xml::XMLPrinter& printer)
		{
			printer.OpenElement("init_from");
			printer.PushText(init_from.c_str());
			printer.CloseElement();
		}
	};

	struct Sampler2D
	{
		std::string source;
		std::string wrap_s;
		std::string wrap_t;
		std::string min_filter;
		std::string mag_filter;
		std::string mip_filter;

		void read(xml::XMLElement* element)
		{
			assert(strcmp(element->Value(), "sampler2D") == 0);

			source = GetText(element->FirstChildElement("source"));

			wrap_s = GetText(element->FirstChildElement("wrap_s"), "");
			wrap_t = GetText(element->FirstChildElement("wrap_t"), "");
			min_filter = GetText(element->FirstChildElement("minfilter"), "");
			mag_filter = GetText(element->FirstChildElement("magfilter"), "");
			mip_filter = GetText(element->FirstChildElement("mipfilter"), "");
		}

		void write(xml::XMLPrinter& printer)
		{
			printer.OpenElement("source");
			printer.PushText(source.c_str());
			printer.CloseElement();

			printer.OpenElement("wrap_s");
			printer.PushText(wrap_s.c_str());
			printer.CloseElement();

			printer.OpenElement("wrap_t");
			printer.PushText(wrap_t.c_str());
			printer.CloseElement();

			printer.OpenElement("minfilter");
			printer.PushText(min_filter.c_str());
			printer.CloseElement();

			printer.OpenElement("magfilter");
			printer.PushText(mag_filter.c_str());
			printer.CloseElement();

			printer.OpenElement("mipfilter");
			printer.PushText(mip_filter.c_str());
			printer.CloseElement();
		}
	};

	struct NewParam
	{
		std::string		sid;
		Value::Type		value_type;
		uint32_t		element_count;
		uint32_t		element_stride;

		union
		{
			void*		generic_value;
			float*		float_value;
			Surface*	surface_value;
			Sampler2D*	sampler_value;
		};

		NewParam(): value_type(Value::Invalid)
		{

		}

		NewParam(const NewParam& that):
		sid(that.sid),
			value_type(that.value_type),
			element_count(that.element_count),
			element_stride(that.element_stride)
		{
			switch(value_type)
			{
			case Value::Float:
				float_value = new float[element_count]; 
				memcpy(float_value, that.float_value, sizeof(float) * element_count);
				break;
			case Value::Surface: 
				surface_value = new Surface(*that.surface_value);
				break;
			case Value::Sampler2D:
				sampler_value = new Sampler2D(*that.sampler_value);
				break;
			}
		}

		NewParam(NewParam&& that)
		{
			sid = std::move(that.sid);
			value_type = that.value_type;
			element_count = that.element_count;
			element_stride = that.element_stride;
			generic_value = that.generic_value;
			that.value_type = Value::Invalid;
		}

		NewParam& operator = (const NewParam& that)
		{
			if (this == &that) return *this;
			dispose();

			sid = that.sid;
			value_type = that.value_type;
			element_count = that.element_count;
			element_stride = that.element_stride;

			switch(value_type)
			{
			case Value::Float:
				float_value = new float[element_count]; 
				memcpy(float_value, that.float_value, sizeof(float) * element_count);
				break;
			case Value::Surface: 
				surface_value = new Surface(*that.surface_value);
				break;
			case Value::Sampler2D:
				sampler_value = new Sampler2D(*that.sampler_value);
				break;
			}

			return *this;
		}

		NewParam& operator = (NewParam&& that)
		{
			if (this == &that) return *this;
			dispose();

			sid = std::move(that.sid);
			value_type = that.value_type;
			element_count = that.element_count;
			element_stride = that.element_stride;
			generic_value = that.generic_value;
			that.value_type = Value::Invalid;

			return *this;
		}

		~NewParam()
		{
			dispose();
		}

		void dispose()
		{
			switch(value_type)
			{
			case Value::Float: delete[] float_value; break;
			case Value::Surface: delete surface_value; break;
			case Value::Sampler2D: delete sampler_value; break;
			}
			value_type = Value::Invalid;
		}

		void read(xml::XMLElement* element)
		{
			assert(strcmp(element->Value(), "newparam") == 0);

			const char* sid_attribute = element->Attribute("sid");
			assert(sid_attribute);
			sid = sid_attribute;

			value_type = Value::Invalid;
			element_count = 0;
			element_stride = 1;

			xml::XMLElement* value_element = element->FirstChildElement();
			do 
			{
				const char* value_type_name = value_element->Value();
				if (strcmp(value_type_name, "surface") == 0)
				{
					value_type = Value::Surface;
					surface_value = new Surface();
					surface_value->read(value_element);
					break;
				}
				else if (strcmp(value_type_name, "sampler2D") == 0)
				{
					value_type = Value::Sampler2D;
					sampler_value = new Sampler2D();
					sampler_value->read(value_element);
					break;
				}
				else if (strncmp(value_type_name, "float", 5) == 0)
				{
					int x = 1, y = 1;
					sscanf_s(value_type_name, "float%dx%d", &x, &y);
					assert(x > 0 && x <=4);
					assert(y > 0 && y <= 4);

					element_count = x * y;
					element_stride = x;

					value_type = Value::Float;
					float_value = new float[element_count];
					ReadFloatArray(float_value, element_count, value_element->GetText());
					break;
				}

				value_element = value_element->NextSiblingElement();
			} while (value_element);

			assert(value_type != Value::Invalid);
		}

		void write(xml::XMLPrinter& printer)
		{
			printer.PushAttribute("sid", sid.c_str());

			if (value_type == Value::Surface)
			{
				printer.OpenElement("surface");
				surface_value->write(printer);
				printer.CloseElement();
			}
			else if (value_type == Value::Sampler2D)
			{
				printer.OpenElement("sampler2D");
				sampler_value->write(printer);
				printer.CloseElement();
			}
			else if (value_type == Value::Float)
			{
				char value_type_name[10];
				if (element_count == 1) 
					strcpy_s(value_type_name, "float");
				else if (element_stride == element_count)
					sprintf_s(value_type_name, "float%d", element_stride);
				else
					sprintf_s(value_type_name, "float%dx%d", element_stride, element_count / element_stride);

				std::string value = WriteFloatArray(float_value, element_count);

				printer.OpenElement(value_type_name);
				printer.PushText(value.c_str());
				printer.CloseElement();
			}
			else
			{
				assert(false);
			}
		}

	};

	struct Include
	{
		std::string sid;
		std::string url;

		void read(xml::XMLElement* element)
		{
			assert(strcmp(element->Value(), "include") == 0);

			const char* sid_attribute = element->Attribute("sid");
			assert(sid_attribute);
			sid = sid_attribute;

			const char* url_attribute = element->Attribute("url");
			assert(url_attribute);
			url = url_attribute;
		}

		void write(xml::XMLPrinter& printer)
		{
			printer.PushAttribute("sid", sid.c_str());
			printer.PushAttribute("url", url.c_str());
		}
	};

	struct Bind
	{
		std::string symbol;
		std::string ref;

		void read(xml::XMLElement* element)
		{
			assert(strcmp(element->Value(), "bind") == 0);

			const char* symbol_attribute = element->Attribute("symbol");
			assert(symbol_attribute);
			symbol = symbol_attribute;

			xml::XMLElement* param_element = element->FirstChildElement("param");
			assert(param_element);

			const char* ref_attribute = param_element->Attribute("ref");
			assert(ref_attribute);
			ref = ref_attribute;
		}

		void write(xml::XMLPrinter& printer)
		{
			printer.PushAttribute("symbol", symbol.c_str());

			printer.OpenElement("param");
			printer.PushAttribute("ref", ref.c_str());
			printer.CloseElement();
		}
	};

	struct Shader
	{
		std::string stage;
		std::string source;
		std::vector<Bind> binds;

		void read(xml::XMLElement* element)
		{
			assert(strcmp(element->Value(), "shader") == 0);

			const char* stage_attribute = element->Attribute("stage");
			assert(stage_attribute);
			stage = stage_attribute;

			xml::XMLElement* name_element = element->FirstChildElement("name");
			assert(name_element);

			const char* source_attribute = name_element->Attribute("source");
			assert(source_attribute);
			source = source_attribute;

			ReadMultipleElements(element, "bind", binds);
		}

		void write(xml::XMLPrinter& printer)
		{
			printer.PushAttribute("stage", stage.c_str());

			printer.OpenElement("name");
			printer.PushAttribute("source", source.c_str());
			printer.CloseElement();

			WriteMultipleElements(printer, "bind", binds);
		}
	};

	struct BlendFunc
	{
		std::string src;
		std::string dest;

		BlendFunc()
		{
			src = "ONE";
			dest = "ZERO";
		}

		bool IsDefault() const
		{
			return src == "ONE" && dest == "ZERO";
		}

		void read(xml::XMLElement* element)
		{
			assert(strcmp(element->Value(), "blend_func") == 0);

			xml::XMLElement* src_element = element->FirstChildElement("src");
			if (src_element)
			{
				const char* value_attribute = src_element->Attribute("value");
				if (value_attribute) src = value_attribute;
			}

			xml::XMLElement* dest_element = element->FirstChildElement("dest");
			if (dest_element)
			{
				const char* value_attribute = dest_element->Attribute("value");
				if (value_attribute) dest = value_attribute;
			}
		}

		void write(xml::XMLPrinter& printer)
		{
			printer.OpenElement("src");
			printer.PushAttribute("value", src.c_str());
			printer.CloseElement();

			printer.OpenElement("dest");
			printer.PushAttribute("value", dest.c_str());
			printer.CloseElement();
		}
	};

	struct Pass
	{
		std::vector<Shader> shaders;
		BlendFunc blend_func;
		bool depth_mask;
		bool cull_face_enable;

		Pass()
		{
			depth_mask = true;
			cull_face_enable = true;
		}

		void read(xml::XMLElement* element)
		{
			assert(strcmp(element->Value(), "pass") == 0);

			xml::XMLElement* blend_func_element = element->FirstChildElement("blend_func");
			if (blend_func_element) blend_func.read(blend_func_element);

			xml::XMLElement* depth_mask_element = element->FirstChildElement("depth_mask");
			if (depth_mask_element)
			{
				depth_mask_element->QueryBoolAttribute("value", &depth_mask);
			}

			xml::XMLElement* cull_face_enable_element = element->FirstChildElement("cull_face_enable");
			if (cull_face_enable_element)
			{
				cull_face_enable_element->QueryBoolAttribute("value", &cull_face_enable);
			}

			ReadMultipleElements(element, "shader", shaders);
			assert(shaders.size() == 2);
		}

		void write(xml::XMLPrinter& printer)
		{
			if (!blend_func.IsDefault())
			{
				printer.OpenElement("blend_func");
				blend_func.write(printer);
				printer.CloseElement();
			}

			if (!depth_mask)
			{
				printer.OpenElement("depth_mask");
				printer.PushAttribute("value", depth_mask);
				printer.CloseElement();
			}

			if (!cull_face_enable)
			{
				printer.OpenElement("cull_face_enable");
				printer.PushAttribute("value", depth_mask);
				printer.CloseElement();
			}

			WriteMultipleElements(printer, "shader", shaders);
		}
	};

	struct Technique
	{
		std::vector<Pass> passes;

		void read(xml::XMLElement* element)
		{
			assert(strcmp(element->Value(), "technique") == 0);

			ReadMultipleElements(element, "pass", passes);
			assert(passes.size() == 1);
		}

		void write(xml::XMLPrinter& printer)
		{
			WriteMultipleElements(printer, "pass", passes);
		}
	};

	struct ProfileCg
	{
		std::vector<Include> includes;
		std::vector<NewParam> new_params;
		std::vector<Technique> techniques;

		void read(xml::XMLElement* element)
		{
			assert(strcmp(element->Value(), "profile_CG") == 0);

			ReadMultipleElements(element, "include", includes);
			assert(includes.size() == 2);

			ReadMultipleElements(element, "newparam", new_params);

			ReadMultipleElements(element, "technique", techniques);
			assert(techniques.size() == 1);
		}

		void write(xml::XMLPrinter& printer)
		{
			WriteMultipleElements(printer, "include", includes);

			WriteMultipleElements(printer, "newparam", new_params);

			WriteMultipleElements(printer, "technique", techniques);
		}

		Include* get_include_from_sid(const std::string& sid)
		{
			for (auto it = includes.begin(); it != includes.end(); ++it)
			{
				if (it->sid == sid) return &*it;
			}
			return nullptr;
		}

	};

	struct Effect
	{
		std::string id;
		std::vector<ProfileCg> profile_cgs;

		void read(xml::XMLElement* element)
		{
			assert(strcmp(element->Value(), "effect") == 0);

			id = element->Attribute("id");

			ReadMultipleElements(element, "profile_CG", profile_cgs);
			assert(profile_cgs.size() == 1);
		}

		void write(xml::XMLPrinter& printer)
		{
			printer.PushAttribute("id", id.c_str());

			WriteMultipleElements(printer, "profile_CG", profile_cgs);
		}
	};

	struct LibraryEffects
	{
		std::vector<Effect> effects;

		void read(xml::XMLElement* element)
		{
			assert(strcmp(element->Value(), "library_effects") == 0);

			ReadMultipleElements(element, "effect", effects);
		}

		void write(xml::XMLPrinter& printer)
		{
			WriteMultipleElements(printer, "effect", effects);
		}
	};
};
