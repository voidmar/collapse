#pragma once

#include <string>
#include <sstream>
#include <cstdint>
#include <vector>
#include <assert.h>
#include <memory>

#include "tinyxml2.h"
namespace xml = tinyxml2;

const char* GetText(xml::XMLElement* element, const char* default)
{
	return element ? element->GetText() : default;
}

const char* GetText(xml::XMLElement* element)
{
	assert(element);
	return element->GetText();
}

template <typename T> 
void ReadMultipleElements(xml::XMLElement* parent, const char* name, std::vector<T>& values)
{
	xml::XMLElement* value_element = parent->FirstChildElement(name);
	while (value_element)
	{
		T value;
		value.read(value_element);
		values.emplace_back(std::move(value));

		value_element = value_element->NextSiblingElement(name);
	} 
}

template <typename T>
void WriteMultipleElements(xml::XMLPrinter& printer, const char* name, std::vector<T>& values)
{
	for (auto it = values.begin(); it != values.end(); ++it)
	{
		printer.OpenElement(name);
		it->write(printer);
		printer.CloseElement();
	}
}

void ReadFloatArray(float* out, uint32_t array_length, const char* string)
{
	for (uint32_t i = 0; i < array_length; ++i)
	{
		char* next = nullptr;
		out[i] = (float)strtod(string, &next);
		assert(next != string); // conversion error
		string = next;
	}
}

std::string WriteFloatArray(float* in, uint32_t array_length)
{
	std::ostringstream out;
	out << *in;
	for (uint32_t i = 1; i < array_length; ++i)
	{
		out << " " << in[i];
	}
	return out.str();
}

void ReadLongArray(long* out, uint32_t array_length, const char* string)
{
	for (uint32_t i = 0; i < array_length; ++i)
	{
		char* next = nullptr;
		out[i] = strtol(string, &next, 10);
		assert(next != string); // conversion error
		string = next;
	}
}

std::string WriteLongArray(long* in, uint32_t array_length)
{
	std::ostringstream out;
	out << *in;
	for (uint32_t i = 1; i < array_length; ++i)
	{
		out << " " << in[i];
	}
	return out.str();
}
