#pragma once
#include "collada_common.h"
#include "collada_material.h"
#include <memory>

struct TransformElement
{
	std::string sid;

	virtual const char* ElementName() const = 0;

	virtual void read(xml::XMLElement* element) = 0
	{
		const char* sid_attribute = element->Attribute("sid");
		assert(sid_attribute);
		sid = sid_attribute;
	}

	virtual void write(xml::XMLPrinter& printer) = 0
	{
		printer.PushAttribute("sid", sid.c_str());
	}
};

struct MatrixTransformElement: public TransformElement
{
	float matrix[16];

	const char* ElementName() const { return "matrix"; }

	void read(xml::XMLElement* element)
	{
		TransformElement::read(element);

		const char* matrix_text = element->GetText();
		assert(matrix_text);
		ReadFloatArray(matrix, 16, matrix_text);
	}

	void write(xml::XMLPrinter& printer)
	{
		TransformElement::write(printer);

		std::string matrix_text = WriteFloatArray(matrix, 16);
		printer.PushText(matrix_text.c_str());
	}
};

struct RotateTransformElement: public TransformElement
{
	float rotation[4]; // axyzis angle

	const char* ElementName() const { return "rotate"; }

	void read(xml::XMLElement* element)
	{
		TransformElement::read(element);

		const char* rotation_text = element->GetText();
		assert(rotation_text);
		ReadFloatArray(rotation, 4, rotation_text);
	}

	void write(xml::XMLPrinter& printer)
	{
		TransformElement::write(printer);

		std::string rotation_text = WriteFloatArray(rotation, 4);
		printer.PushText(rotation_text.c_str());
	}
};

struct TranslateTransformElement: public TransformElement
{
	float offset[3];

	const char* ElementName() const { return "translate"; }

	void read(xml::XMLElement* element)
	{
		TransformElement::read(element);

		const char* offset_text = element->GetText();
		assert(offset_text);
		ReadFloatArray(offset, 3, offset_text);
	}

	void write(xml::XMLPrinter& printer)
	{
		TransformElement::write(printer);

		std::string offset_text = WriteFloatArray(offset, 3);
		printer.PushText(offset_text.c_str());
	}
};

struct ScaleTransformElement: public TransformElement
{
	float scale[3];

	const char* ElementName() const { return "scale"; }

	void read(xml::XMLElement* element)
	{
		TransformElement::read(element);

		const char* scale_text = element->GetText();
		assert(scale_text);
		ReadFloatArray(scale, 3, scale_text);
	}

	void write(xml::XMLPrinter& printer)
	{
		TransformElement::write(printer);

		std::string scale_text = WriteFloatArray(scale, 3);
		printer.PushText(scale_text.c_str());
	}
};


struct InstanceGeometry
{
	std::string url;
	std::vector<InstanceMaterial> instance_materials;

	void read(xml::XMLElement* element)
	{
		url = element->Attribute("url");

		xml::XMLElement* bind_material_element = element->FirstChildElement("bind_material");
		assert(bind_material_element);

		xml::XMLElement* technique_common_element = bind_material_element->FirstChildElement("technique_common");
		assert(technique_common_element);

		ReadMultipleElements(technique_common_element, "instance_material", instance_materials);
	}

	void write(xml::XMLPrinter& printer)
	{
		printer.PushAttribute("url", url.c_str());

		printer.OpenElement("bind_material");
		printer.OpenElement("technique_common");

		WriteMultipleElements(printer, "instance_material", instance_materials);

		printer.CloseElement();
		printer.CloseElement();
	}
};

struct Node
{
	std::string id;
	std::string type;
	std::vector<std::shared_ptr<TransformElement>> transforms;
	std::vector<InstanceGeometry> instance_geometries;
	std::vector<Node> nodes;

	void read(xml::XMLElement* element)
	{
		id = element->Attribute("id");
		type = element->Attribute("type");

		xml::XMLElement* child_element = element->FirstChildElement();
		assert(child_element);

		do 
		{
			const char* child_type_name = child_element->Value();
			if (strcmp(child_type_name, "node") == 0)
			{
				Node node;
				node.read(child_element);
				nodes.emplace_back(std::move(node));
			}
			else if (strcmp(child_type_name, "instance_geometry") == 0)
			{
				InstanceGeometry instance_geometry;
				instance_geometry.read(child_element);
				instance_geometries.emplace_back(std::move(instance_geometry));
			}
			else if (strcmp(child_type_name, "matrix") == 0)
			{
				std::shared_ptr<TransformElement> transform_element(new MatrixTransformElement());
				transform_element->read(child_element);
				transforms.emplace_back(std::move(transform_element));
			}
			else if (strcmp(child_type_name, "rotate") == 0)
			{
				std::shared_ptr<TransformElement> transform_element(new RotateTransformElement());
				transform_element->read(child_element);
				transforms.emplace_back(std::move(transform_element));
			}
			else if (strcmp(child_type_name, "translate") == 0)
			{
				std::shared_ptr<TransformElement> transform_element(new TranslateTransformElement());
				transform_element->read(child_element);
				transforms.emplace_back(std::move(transform_element));
			}
			else if (strcmp(child_type_name, "scale") == 0)
			{
				std::shared_ptr<TransformElement> transform_element(new ScaleTransformElement());
				transform_element->read(child_element);
				transforms.emplace_back(std::move(transform_element));
			}

			child_element = child_element->NextSiblingElement();
		} while (child_element);
	}

	void write(xml::XMLPrinter& printer)
	{
		printer.PushAttribute("id", id.c_str());
		printer.PushAttribute("type", type.c_str());

		for (auto it = transforms.begin(); it != transforms.end(); ++it)
		{
			std::shared_ptr<TransformElement> transform_element = *it;
			printer.OpenElement(transform_element->ElementName());
			transform_element->write(printer);
			printer.CloseElement();
		}

		WriteMultipleElements(printer, "instance_geometry", instance_geometries);

		WriteMultipleElements(printer, "node", nodes);
	}
};

struct VisualScene
{
	std::string id;
	std::string name;
	std::vector<Node> nodes;

	void read(xml::XMLElement* element)
	{
		assert(strcmp(element->Value(), "visual_scene") == 0);

		id = element->Attribute("id");
		name = element->Attribute("name");

		ReadMultipleElements(element, "node", nodes);
	}

	void write(xml::XMLPrinter& printer)
	{
		printer.PushAttribute("id", id.c_str());
		printer.PushAttribute("name", name.c_str());

		WriteMultipleElements(printer, "node", nodes);
	}
};

struct LibraryVisualScenes
{
	std::vector<VisualScene> visual_scenes;

	void read(xml::XMLElement* element)
	{
		assert(strcmp(element->Value(), "library_visual_scenes") == 0);

		ReadMultipleElements(element, "visual_scene", visual_scenes);
	}

	void write(xml::XMLPrinter& printer)
	{
		WriteMultipleElements(printer, "visual_scene", visual_scenes);
	}
};