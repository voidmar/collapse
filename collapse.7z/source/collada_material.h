#pragma once
#include "collada_common.h"

struct Material
{
	std::string id;
	std::string name;
	std::string instance_effect_url;

	void read(xml::XMLElement* element)
	{
		id = element->Attribute("id");
		name = element->Attribute("name");

		xml::XMLElement* instance_effect_element = element->FirstChildElement("instance_effect");
		assert(instance_effect_element);

		const char* url_attribute = instance_effect_element->Attribute("url");
		assert(url_attribute);
		instance_effect_url = url_attribute;
	}

	void write(xml::XMLPrinter& printer)
	{
		printer.PushAttribute("id", id.c_str());
		printer.PushAttribute("name", name.c_str());

		printer.OpenElement("instance_effect");
		printer.PushAttribute("url", instance_effect_url.c_str());
		printer.CloseElement();
	}
};


struct LibraryMaterials
{
	std::vector<Material> materials;

	void read(xml::XMLElement* element)
	{
		ReadMultipleElements(element, "material", materials);
	}

	void write(xml::XMLPrinter& printer)
	{
		WriteMultipleElements(printer, "material", materials);
	}
};

struct InstanceMaterial
{
	std::string symbol;
	std::string target;

	void read(xml::XMLElement* element)
	{
		symbol = element->Attribute("symbol");
		target = element->Attribute("target");
	}

	void write(xml::XMLPrinter& printer)
	{
		printer.PushAttribute("symbol", symbol.c_str());
		printer.PushAttribute("target", target.c_str());
	}
};