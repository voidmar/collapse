#pragma once
#include "collada_common.h"
#include "collada_dataflow.h"

struct Sampler
{
	std::string id;
	std::vector<Input> inputs;

	void read(xml::XMLElement* element)
	{
		id = element->Attribute("id");

		ReadMultipleElements(element, "input", inputs);
	}

	void write(xml::XMLPrinter& printer)
	{
		printer.PushAttribute("id", id.c_str());

		WriteMultipleElements(printer, "input", inputs);
	}
};

struct Channel
{
	std::string source;
	std::string target;

	void read(xml::XMLElement* element)
	{
		source = element->Attribute("source");
		target = element->Attribute("target");
	}

	void write(xml::XMLPrinter& printer)
	{
		printer.PushAttribute("source", source.c_str());
		printer.PushAttribute("target", target.c_str());
	}
};

struct Animation
{
	std::string id;
	std::vector<Source> sources;
	std::vector<Sampler> samplers;
	std::vector<Channel> channels;

	void read(xml::XMLElement* element)
	{
		id = element->Attribute("id");

		ReadMultipleElements(element, "source", sources);
		ReadMultipleElements(element, "sampler", samplers);
		ReadMultipleElements(element, "channel", channels);
	}

	void write(xml::XMLPrinter& printer)
	{
		printer.PushAttribute("id", id.c_str());

		WriteMultipleElements(printer, "source", sources);
		WriteMultipleElements(printer, "sampler", samplers);
		WriteMultipleElements(printer, "channel", channels);
	}
};

struct LibraryAnimations
{
	std::vector<Animation> animations;

	void read(xml::XMLElement* element)
	{
		assert(strcmp(element->Value(), "library_animations") == 0);

		ReadMultipleElements(element, "animation", animations);
	}

	void write(xml::XMLPrinter& printer)
	{
		WriteMultipleElements(printer, "animation", animations);
	}
};